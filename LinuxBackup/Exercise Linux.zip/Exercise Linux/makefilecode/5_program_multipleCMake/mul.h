#ifndef _SUB_H
#define _SUB_H


int sub(int a , int b);



#endif
