#include "mul.h"

int mul(int a, int b)
{
    return (a*b);
}

 
