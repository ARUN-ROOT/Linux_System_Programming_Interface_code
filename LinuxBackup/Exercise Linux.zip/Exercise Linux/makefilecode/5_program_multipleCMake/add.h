#ifndef _ADD_H
#define _ADD_H


int add(int a , int b);



#endif
