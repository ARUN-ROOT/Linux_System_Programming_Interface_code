#ifndef _MUL_H
#define _MUL_H


int mul(int a , int b);



#endif
