#include <stdio.h>
#include "add.h"

int main()
{
  printf("main code\n");
  add(2,55);
}
