#include "add.h"

void add(int a, int b)
{
    printf("addition code %d\n",a+b);
    
}

 
