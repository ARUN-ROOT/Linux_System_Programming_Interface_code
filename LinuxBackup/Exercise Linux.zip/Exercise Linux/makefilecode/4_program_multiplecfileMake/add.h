#ifndef _ADD_H_
#define _ADD_H
#include <stdio.h>
void add(int a , int b);



#endif
