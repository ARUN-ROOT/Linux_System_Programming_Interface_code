/************************************************************************************************************/
/* Name			:  Header.c                         */	   
/* Date			: 26/2/2023                                                                 */
/* Author			: Arun.V                                                                     */
/* Code link			: 									        */ 
/* Descrition			: Header definitions	*/
/*			          */
/* o/p				: 



*/
                                                                                        
/************************************************************************************************************/
#include <stdio.h>

char name(char *c)
{
  printf("your name %s \n",c);
}

int age(int i)
{
  printf("your age %d \n",i);
}

