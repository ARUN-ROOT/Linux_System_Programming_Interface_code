header.h	header.c	main.c(argv[])

		header.o	main.o
		
		gcc header.o main.o -o info
		
			./info 25
			
			o/p:your age:25
