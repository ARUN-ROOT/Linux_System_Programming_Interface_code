here,semaphore is removed by using semctl in Other process.not main processs
