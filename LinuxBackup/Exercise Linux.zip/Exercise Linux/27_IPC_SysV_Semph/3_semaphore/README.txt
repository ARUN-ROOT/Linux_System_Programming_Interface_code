practise.c file writing the content during that time other proccess wait until finish .
once finish , process1.c reading file
